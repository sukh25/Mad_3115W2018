//
//  ViewController.swift
//  design
//
//  Created by MacStudent on 2018-02-20.
//  Copyright © 2018 Prabhjot. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
  
    @IBOutlet weak var labelEmail: UILabel!
    @IBOutlet weak var txtEmail: UITextField!
    
   
    @IBOutlet weak var labelPassword: UILabel!
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var labelAddress: UILabel!
    @IBOutlet weak var txtAddress: UITextField!
    
    @IBOutlet weak var labelContact: UILabel!
    @IBOutlet weak var txtContact: UITextField!
    
    @IBOutlet weak var buttonLogin: UIButton!
    
    
    
    @IBAction func buttonLoginAction(_ sender: UIButton) {
     
        var email = txtEmail.text!
        labelEmail.text = email
        
        var password = txtPassword.text!
        labelPassword.text = password
        
        var address = txtAddress.text!
        labelAddress.text = address
        
        var contactNo = txtContact.text!
        labelContact.text = contactNo
        
        
        //instance
        let infoAlert = UIAlertController(title: "Is the information correct", message: txtEmail.text!, preferredStyle: .actionSheet )
        
        //add button
        infoAlert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
        
        infoAlert.addAction(UIAlertAction(title: "NO", style: .default, handler: nil))
        
        infoAlert.addAction(UIAlertAction(title: "Maybe", style: .default, handler: nil))
        
        //display
        self.present(infoAlert, animated: true, completion:  nil)
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

