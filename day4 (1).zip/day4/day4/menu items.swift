//
//  menu items.swift
//  day4
//
//  Created by MacStudent on 2018-02-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class MenuItems {
        let names:[String] = [
        "pizza","maggi",
        "chocolate","chicken",
        "popcorn","ketchup",
        "BBQ","fish",
        "potato","onion",
        "ginger","garlic"
    ]

    let prices:[Double] = [
        7.99,3.55,
        5.66,9.99,
        76.88,8.99,
        9.88,76.77,
        76.88,5.77,
        99.9,8.25
    ]
    let specials:[Bool] = [
        false,true,
        false,true,
        false,true,
        false,true,
        false,true,
        false,true
    ]
}
