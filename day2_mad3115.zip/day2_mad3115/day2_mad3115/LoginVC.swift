//
//  ViewController.swift
//  day2_mad3115
//
//  Created by MacStudent on 2018-02-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    
    
    @IBOutlet weak var txtPassword: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func btnLoginAction(_ sender: UIBarButtonItem) {
   
        let email = txtEmail.text
        let password = txtPassword.text
        
        if(email == "test" && password == "test"){
            
            
            let infoAlert = UIAlertController(title: "login successful", message : "you r authenticated", preferredStyle : .alert)
            
            infoAlert.addAction(UIAlertAction(title:"Okay", style: .default, handler: nil))
            
            
            self.present(infoAlert, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnRegisterAction(_ sender: UIBarButtonItem) {
   
    
        let registerSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let registerVC = registerSB.instantiateViewController(withIdentifier: "RegistrtaionScreen")
        
       // self.present(registerVC, animated: true, completion: nil)
        
        navigationController?.pushViewController(registerVC, animated: true)
        
    }
    
    
}

