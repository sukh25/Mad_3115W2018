//
//  ViewController.swift
//  day 8
//
//  Created by MacStudent on 2018-03-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController {

   // let lambtonCollegeLocation = CLLocation(latitude: 43.77745, longitude: -79.34355)
    
    //portion of distinct we want to show or to zoom in
    
    let regionRadius: CLLocationAccuracy = 500
    let locationManager = CLLocationManager()
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //selecting  map type
        
        
        myMap.mapType = MKMapType.hybrid
        
        
      //  centerMapOnLocation(location: lambtonCollegeLocation, title: "233", subtitle: "yorkland")
        
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.startUpdatingLocation()
        }
        
        
    }

   
    @IBOutlet weak var myMap: MKMapView!
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

//center map on specified location
    func centerMapOnLocation(location: CLLocation, title: String, subtitle: String){
        
        // get location cordinates
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,regionRadius,regionRadius)
        
         //focusing on particular point
        myMap.setRegion(coordinateRegion, animated: true)
        
        let  myAnnotation:  MKPointAnnotation = MKPointAnnotation()
        
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        myAnnotation.title = title
        myAnnotation.subtitle = subtitle
        
        //display pin on loc
        myMap.addAnnotation(myAnnotation)
        
        
    }
}

extension ViewController: CLLocationManagerDelegate{
    
    func  locationManager(_ manager: CLLocationManager, didFailWithError error: Error){
        print("error: \(error.localizedDescription)")
}

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus){
        if status == .authorizedWhenInUse
        {
            locationManager.requestLocation()
        }
        
        }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        if locations.first != nil {
            print("location: \(locations)")
        }
        centerMapOnLocation(location: locationManager.location!, title: "current", subtitle: "47th" )
    }

}
